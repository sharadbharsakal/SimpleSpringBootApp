package com.example.Conduiro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConduiroApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConduiroApplication.class, args);
	}

}
