package com.example.Conduiro;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppConfiguration {
    @RequestMapping("/")
    public String hello()
    {

        return "hello all this is simple spring boot project";

    }

}
